package chat.kata

class ChatController {

	def list(Integer seq) {
		//TODO: implement me
	}

	def send(){
		//TODO: implement me
	}
}
