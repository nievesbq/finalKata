package org.ejmc.android.simplechat.model;


/**
 * List off chat messages..
 * 
 * @author startic
 *
 */
public class ChatList {
	
	
}
