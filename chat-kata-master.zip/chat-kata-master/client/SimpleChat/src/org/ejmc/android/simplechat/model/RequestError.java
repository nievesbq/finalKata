package org.ejmc.android.simplechat.model;


/**
 * Server request error.
 * 
 * @author startic
 * 
 */
public class RequestError {


}
